from .app import BitScoreApp
